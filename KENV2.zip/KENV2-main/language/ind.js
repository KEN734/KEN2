exports.wait = () => {
	return`*⌛ Por favor, aguarde um pouco... ⌛*`
}

exports.succes = () => {
	return`*SUCESSO ✔*`
}

exports.lvlon = () => {
	return`*「 HABILITAR 」 NIVEL*`
}

exports.lvloff = () => {
	return`*「 DESATIVAR 」 NIVEL*`
}

exports.lvlnul = () => {
	return`*SEU NÍVEL AINDA ESTÁ VAZIO*`
}

exports.lvlnoon = () => {
	return`*O NÍVEL NÃO FOI ATIVADO*`
}

exports.noregis = () => {
	return`*「 REGISTRE-SE 」*\n\n*para ter acesso ao menu você tem que se cadastrar! Para se cadastrar use os comandos:\n daftar ${prefix}daftar nome|idade* \n*ex: ${prefix}daftar KEN|18*`
}

exports.rediregis = () => {
	return`*「 CADASTRADO 」*\n\n*você já está cadastrado do banco de dados do  KEN BOT*`
}

exports.stikga = () => {
	return`*[ ❗ ] Falha tente novamente mais tarde*`
}

exports.linkga = () => {
	return`*[ ❗ ] link inválido*`
}

exports.groupo = () => {
	return`*[ ❗ ] Esse comando só pode ser usado em grupos*`
}

exports.ownerb = () => {
	return`*[ ❗ ] Esse comando só pode ser usado pelo KEN*`
}

exports.ownerg = () => {
	return`*[ ❗ ] Esse comando só pode ser usado se você e o bot forem admins*`
}

exports.admin = () => {
	return`*[ ❗ ] Esse comando só pode ser usado se você for admim*`
}

exports.badmin = () => {
	return`*[ ❗ ] Esse comando só pode ser usado se o bot for admim*`
}

exports.nsfwoff = () => {
	return`*modo NSFW ativo nesse grupo ✔*`
}

exports.bug = () => {
	return`*Problemas foram relatados ao proprietário do BOT*`
}

exports.wrongf = () => {
	return`*Formato incorreto/texto em branco*`
}

exports.clears = () => {
	return`*chat do bot limpo com sucesso ✔*`
}

exports.pc = () => {
	return`*「REGISTRO」*\n\npara saber se você se registrou, verifique a mensagem que enviei\n\nNOTA:\n *se você não recebeu uma mensagem significa que você não salvou o número do seu bot* `
}

exports.registered = (namaUser, umurUser, serialUser, time, sender) => {
	return`*「 DATA DE REGISTRO *ARR157 BOT*」*\n\nvocê se registrou com os dados \n\n┏━⊱nome\n┗⊱${namaUser}\n┏━⊱numero\n┗⊱wa.me/${sender.split("@")[0]}\n┏━⊱idade\n┗⊱${umurUser}\n┏━⊱hora de registro\n┗⊱${time}\n\n┏━❉ *NS* ❉━\n┣⊱${serialUser}\n┗⊱NOTA : não se esqueça deste número porque é importante!`
}

exports.cmdnf = (prefix, command) => {
	return`command *${prefix}${command}* tidak di temukan\coba tulis *${prefix}menu*`
}

exports.owneresce = (pushname) => {
	return`*maaf tapi ${pushname} bukan owner script*`
}

exports.reglevelaha = (command, pushname, getLevelingLevel, sender, aha) => {
	return`*Maaf ${pushname} level mu belum mencukupi*\n\n*┏⊱level mu : ${getLevelingLevel(sender)}*\n*┣⊱jenis command : ${command}*\n*┗⊱syarat level : ${aha}*\n\n_NOTE : CHAT/SELALU ON UNTUK MENDAPATKAN XP_`
}

exports.reglevelahb = (command, pushname, getLevelingLevel, sender, ahb) => {
	return`*Maaf ${pushname} seu nível não é suficiente*\n\n*┏⊱seu nível : ${getLevelingLevel(sender)}*\n*┣⊱tipo de comando : ${command}*\n*┗⊱syarat level : ${ahb}*\n\n_NOTE : CHAT / SEMPRE PARA OBTER XP_`
}

exports.reglevelahc = (command, pushname, getLevelingLevel, sender, ahc) => {
	return`*Maaf ${pushname} level mu belum mencukupi*\n\n*┏⊱level mu : ${getLevelingLevel(sender)}*\n*┣⊱jenis command : ${command}*\n*┗⊱syarat level : ${ahc}*\n\n_NOTE : CHAT/SELALU ON UNTUK MENDAPATKAN XP_`
}

exports.reglevelahd = (command, pushname, getLevelingLevel, sender, ahd) => {
	return`*Maaf ${pushname} level mu belum mencukupi*\n\n*┏⊱level mu : ${getLevelingLevel(sender)}*\n*┣⊱jenis command : ${command}*\n*┗⊱syarat level : ${ahd}*\n\n_NOTE : CHAT/SELALU ON UNTUK MENDAPATKAN XP_`
}

exports.reglevelahe = (command, pushname, getLevelingLevel, sender, ahe) => {
	return`*Maaf ${pushname} level mu belum mencukupi*\n\n*┏⊱level mu : ${getLevelingLevel(sender)}*\n*┣⊱jenis command : ${command}*\n*┗⊱syarat level : ${ahe}*\n\n_NOTE : CHAT/SELALU ON UNTUK MENDAPATKAN XP_`
}

exports.reglevelahf = (command, pushname, getLevelingLevel, sender, ahf) => {
	return`*Maaf ${pushname} level mu belum mencukupi*\n\n*┏⊱level mu : ${getLevelingLevel(sender)}*\n*┣⊱jenis command : ${command}*\n*┗⊱syarat level : ${ahf}*\n\n_NOTE : CHAT/SELALU ON UNTUK MENDAPATKAN XP_`
}

exports.menu = (pushname, prefix, getLevelingLevel, getLevelingXp, sender, reqXp, _registered, uangku) => { 
	return `
╭══─⊱ ❰ *SOBRE O USUÁRIO* ❱ ⊰─══
╠☞ *Nome* : ${pushname}
╠☞ *Numero* : wa.me/${sender.split("@")[0]}
╠☞ *O seu dinheiro* : Rp${uangku}
╠☞ *XP* : ${getLevelingXp(sender)}/${reqXp}
╠☞ *Level* : ${getLevelingLevel(sender)}
╠☞ *User register* : ${_registered.length}
╰═══─⊱  ⸨ *KEN BOT* ⸩  ⊰─═══╯

          
▬▭▬▭▬▭▬▭▬▭▬▭▬
●⧐ *Spam : Auto Block!*
●⧐ *Dê uma pausa de 5 segundos ao usá-lo!!*
●⧐ *Bug/Error Harap Cht Owner!*
●⧐ *Untuk Memastikan Bot Off Atau On*
●⧐ *Tipo ${prefix}bot*
●⧐ *Por favor, seja paciente com os bugs!*
●⧐ *Bom uso do bot!*
▬▭▬▭▬▭▬▭▬▭▬▭▬

╭══─⊱ ❰ *MAKER MENU* ❱ ⊰─══➤
╠➥ *${prefix}sticker*
╠➥ *${prefix}vinta*
╠➥ *${prefix}avengers*
╠➥ *${prefix}summer*
╠➥ *${prefix}sandwrite*
╠➥ *${prefix}metaldark*
╠➥ *${prefix}dropwater*
╠➥ *${prefix}greenneon*
╠➥ *${prefix}neontext*
╠➥ *${prefix}sumery*
╠➥ *${prefix}blood*
╠➥ *${prefix}firework*
╠➥ *${prefix}lava*
║
╠══─⊱ ❰ *FULL MENU* ❱ ⊰─════➤
╠➥ *${prefix}mining*
╠➥ *${prefix}bisakah*
╠➥ *${prefix}kapankah*
╠➥ *${prefix}apakah*
╠➥ *${prefix}rate*
╠➥ *${prefix}slap*
╠➥ *${prefix}tampar*
╠➥ *${prefix}speed*
║
╠══─⊱ ❰ *MIDIA MENU* ❱ ⊰─═══➤
╠➥ *${prefix}toxic*
╠➥ *${prefix}quotes*
╠➥ *${prefix}beritahoax*
╠➥ *${prefix}brainly*
╠➥ *${prefix}pinterest*
╠➥ *${prefix}resepmasakan*
╠➥ *${prefix}igstalk*
║
╠══─⊱ ❰ *LIMIT MENU* ❱ ⊰─═══➤
╠➥ *${prefix}limit*
╠➥ *${prefix}buylimit*
╠➥ *${prefix}dompet*
║
╠══─⊱ ❰ *NSFW MENU* ❱ ⊰─═══➤
╠➥ *${prefix}pokemon*
╠➥ *${prefix}anjing*
╠➥ *${prefix}1cak*
║
╠══─⊱ ❰ *GRUPO MENU* ❱ ⊰─══➤
╠➥ *${prefix}hidetag*
╠➥ *${prefix}grouplist*
╠➥ *${prefix}limit*
╠➥ *${prefix}level*
╠➥ *${prefix}linkgc*
╠➥ *${prefix}tagall*
╠➥ *${prefix}setpp*
╠➥ *${prefix}add*
╠➥ *${prefix}kick*
╠➥ *${prefix}setname*
╠➥ *${prefix}setdesc*
╠➥ *${prefix}demote*
╠➥ *${prefix}promote*
╠➥ *${prefix}listadmin*
╠➥ *${prefix}group* [buka/tutup]
╠➥ *${prefix}leveling* [enable/disable]
╠➥ *${prefix}nsfw* [1/0]
╠➥ *${prefix}simih* [1/0]
╠➥ *${prefix}welcome* [1/0]
║
╠══─⊱ ❰ *OWNER MENU* ❱ ⊰─══➤
╠➥ *${prefix}bc*
╠➥ *${prefix}bcgc*
╠➥ *${prefix}kickall*
╠➥ *${prefix}setreply*
╠➥ *${prefix}setprefix*
╠➥ *${prefix}clearall*
╠➥ *${prefix}block*
╠➥ *${prefix}unblock*
╠➥ *${prefix}leave*
╠➥ *${prefix}event* [1/0]
╠➥ *${prefix}clone*
╠➥ *${prefix}setppbot*
║
╠══─⊱ ❰ *KEN DOMINA 🥵* ❱ ⊰─══➤
║
╰═══─⊱  ⸨ *KEN BOT* ⸩  ⊰─═══╯
`
}

exports.levelup = (pushname, sender, getLevelingXp,  getLevel, getLevelingLevel) => {
	return`
*「 Info 」*
┏⊱ *Nome* : ${pushname}
┣⊱ *Número* : wa.me/${sender.split("@")[0]}
┣⊱ *Xp* : ${getLevelingXp(sender)}
┗⊱ *Level* : ${getLevel} ⊱ ${getLevelingLevel(sender)}
`}
 
exports.limitend = (pushname) => {
	return`*maaf ${pushname} O limite de hoje expira*\n*O limite é zerado a cada 24:00 horas*`
}

exports.limitcount = (limitCounts) => {
	return`
*「 LIMITE DE CONTAGEM 」*
sisa limit anda : ${limitCounts}

NOTE : untuk mendapatkan limit. bisa lewat naik level atau buylimit`
}

exports.satukos = () => {
	return`*Tambah parameter 1/enable atau 0/disable`
}

exports.uangkau = (pushname, sender, uangkau) => {
	return`*┏⊱ *「 ATM 」* ━┓\n┣⊱ *Nome* : ${pushname}\n┣⊱ *Número* : ${sender.split("@")[0]}\n┣⊱ *Uang* : ${uangkau}\n┗━━━━━━━━━━`
}
