const config = {
        botName: 'KENBOT',
        ownerName: 'KEN',
        youtube: 'YOUTUBE_LINK',
        instagram: 'INSTAGRAM_LINK',
}
