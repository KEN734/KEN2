const cancer = () => { 
	return `       
Cancer (21 Juni – 20 Juli)

Kanser (♋) (Yunani Kuno: Καρκίνος, Latin: Cancer) adalah zodiak keempat yang berasal dari konstelasi Cancer. Zodiak ini mencakup 90° 120° dari zodiak, antara 90° dan 120° dari tata koordinat langit. Di bawah zodiak tropis, Matahari transit daerah ini antara 22 Juni sampai 22 Juli, dan di bawah sideris, Matahari transit daerah ini dari tanggal 16 Juli sampai 15 Agustus.[1]
Dalam astrologi, Kanser adalah zodiak kardinal dari elemen air, yang terdiri dari Kanser, Pises, dan Skorpio.[2] Zodiak ini berenergi negatif, dan berdomisil di planet Bulan. Kanser berbentuk kepiting, berdasarkan Karkinos, kepiting raksasa yang dilecehkan Heracles selama pertarungannya dengan Hydra.
`
}
exports.cancer = cancer