const paulomenu = (prefix, pushname) => {
    return `◪ *Comandos do KENBOT*
    │
    ├─ ❏ ${prefix}setprefix
    ├─ ❏ ${prefix}block
    ├─ ❏ ${prefix}bc
    ├─ ❏ ${prefix}bcgc
    └─ ❏ ${prefix}clearall`

}

exports.paulomenu = paulomenu
