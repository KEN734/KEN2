const animemenu = (prefix) => { 
	return `
╭┈─────𝙵𝙸𝚃𝚄𝚁 𝙽𝚈𝙰 𝙺𝙰𝙺
╰─❁۪۪
╰─➤ *${prefix}randomanime*
╰─➤ *${prefix}waifu*
╰─➤ *${prefix}waifu2*
╰─➤ *${prefix}nekonime*
╰─➤ *${prefix}wibu*
╰─➤ *${prefix}wait*
╰─➤ *${prefix}inu*
╰─➤ *${prefix}pokemon*
╰─➤ *${prefix}naruto*
╰─➤ *${prefix}hinata*
╰─➤ *${prefix}sasuke*
╰─➤ *${prefix}sakura*
╰─➤ *${prefix}boruto*
╰─➤ *${prefix}minato*
╰─➤ *${prefix}loli*
╰─➤ *${prefix}loli2*
╰─➤ *${prefix}rize*
╰─➤ *${prefix}akira*
╰─➤ *${prefix}itori*
╰─➤ *${prefix}kurumi*
╰─➤ *${prefix}miku*
╭┈─────𝚝𝚑𝚊𝚗𝚡 𝚝𝚘 𝚖𝚊𝚜𝚕𝚎𝚗𝚝 𝚢𝚝
╰─❁۪۪`
}
exports.animemenu = animemenu