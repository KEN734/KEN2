const kerangmenu = (prefix) => { 
	return `
╭┈─────𝙵𝙸𝚃𝚄𝚁 𝙽𝚈𝙰 𝙺𝙰𝙺
╰─❁۪۪
╰─➤ *${prefix}apakah [optional]*
╰─➤ *${prefix}rate [optional]*
╰─➤ *${prefix}bisakah [optional]*
╰─➤ *${prefix}kapankah [optional]*
╰─➤ *${prefix}gantengcek*
╰─➤ *${prefix}toxic*
╰─➤ *${prefix}cantikcek*
╰─➤ *${prefix}persengay*
╭┈─────𝚝𝚑𝚊𝚗𝚡 𝚝𝚘 𝚖𝚊𝚜𝚕𝚎𝚗𝚝 𝚢𝚝
╰─❁۪۪`
}
exports.kerangmenu = kerangmenu