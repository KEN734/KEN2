const config = {
        botName: 'pauloBOT',
        ownerName: 'paulo',
        youtube: 'YOUTUBE_LINK',
        instagram: 'INSTAGRAM_LINK',
}
